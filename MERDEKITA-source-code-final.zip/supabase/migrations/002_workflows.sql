-- Transactional workflow functions: all user actions update participation, XP, and notifications atomically.
create or replace function public.award_xp(p_amount integer,p_source_type text,p_source_id uuid,p_description text)
returns void language plpgsql security definer set search_path=public as $$
begin
 insert into xp_transactions(user_id,amount,source_type,source_id,description) values(auth.uid(),p_amount,p_source_type,p_source_id,p_description);
end; $$;
create or replace function public.register_for_event(p_event_id uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare e events; current_count integer;
begin
 select * into e from events where id=p_event_id and status='PUBLISHED' for update;
 if not found then raise exception 'EVENT_NOT_FOUND'; end if;
 select count(*) into current_count from event_participants where event_id=p_event_id and status='REGISTERED';
 if current_count>=e.capacity then raise exception 'EVENT_FULL'; end if;
 insert into event_participants(event_id,user_id,status) values(p_event_id,auth.uid(),'REGISTERED');
 perform award_xp(e.xp_reward,'EVENT',p_event_id,'Bergabung dengan '||e.title);
 insert into notifications(user_id,title,body) values(auth.uid(),'Pendaftaran berhasil','Kamu bergabung di '||e.title||' dan memperoleh '||e.xp_reward||' XP.');
 return jsonb_build_object('status','REGISTERED','xp',e.xp_reward);
exception when unique_violation then raise exception 'ALREADY_REGISTERED'; end; $$;
create or replace function public.submit_challenge(p_challenge_id uuid,p_evidence text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare c challenges;
begin
 select * into c from challenges where id=p_challenge_id;
 if not found then raise exception 'CHALLENGE_NOT_FOUND'; end if;
 if c.deadline is not null and c.deadline<now() then raise exception 'CHALLENGE_EXPIRED'; end if;
 insert into challenge_submissions(challenge_id,user_id,evidence,status) values(p_challenge_id,auth.uid(),p_evidence,'APPROVED');
 perform award_xp(c.xp_reward,'CHALLENGE',p_challenge_id,'Menyelesaikan '||c.title);
 insert into notifications(user_id,title,body) values(auth.uid(),'Challenge selesai','Kamu memperoleh '||c.xp_reward||' XP dari '||c.title||'.');
 return jsonb_build_object('status','APPROVED','xp',c.xp_reward);
exception when unique_violation then raise exception 'ALREADY_SUBMITTED'; end; $$;
create or replace function public.join_community(p_community_id uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
begin insert into community_members(community_id,user_id) values(p_community_id,auth.uid()); return jsonb_build_object('status','JOINED'); exception when unique_violation then raise exception 'ALREADY_JOINED'; end; $$;
create or replace function public.apply_volunteer(p_opportunity_id uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
begin insert into volunteer_participants(opportunity_id,user_id) values(p_opportunity_id,auth.uid(),'APPLIED'); return jsonb_build_object('status','APPLIED'); exception when unique_violation then raise exception 'ALREADY_APPLIED'; end; $$;
grant execute on function public.register_for_event(uuid),public.submit_challenge(uuid,text),public.join_community(uuid),public.apply_volunteer(uuid) to authenticated;
