insert into public.events(id,slug,title,description,category,city,start_at,capacity,xp_reward,status) values
('10000000-0000-4000-8000-000000000001','festival-kreativitas-medan','Festival Kreativitas Medan','Panggung kreator muda dan UMKM lokal di Lapangan Merdeka.','Creative','Medan','2026-08-25T09:00:00+07',200,50,'PUBLISHED'),
('10000000-0000-4000-8000-000000000002','lari-merdeka-pantai','Lari Merdeka Pantai','Lari pagi bersama untuk kota yang lebih sehat.','Sports','Medan','2026-08-24T06:00:00+07',100,50,'PUBLISHED') on conflict (id) do nothing;
insert into public.challenges(id,slug,title,description,instructions,category,submission_type,xp_reward,deadline) values
('20000000-0000-4000-8000-000000000001','dukung-produk-lokal','Dukung Produk Lokal','Kunjungi UMKM tetangga dan bagikan ceritanya.','Tulis nama UMKM dan dampak dukunganmu.','Social','text',100,'2026-08-31T23:59:59+07'),
('20000000-0000-4000-8000-000000000002','kenali-indonesiamu','Kenali Indonesiamu','Pelajari satu cerita budaya lokal hari ini.','Kirim ringkasan cerita budaya yang kamu pelajari.','Culture','text',100,'2026-08-22T23:59:59+07') on conflict (id) do nothing;
insert into public.badges(code,name,rule) values
('LOCAL_HERO','Local Hero','{"community_activities":5}'),('GREEN_WARRIOR','Green Warrior','{"environment_challenges":3}'),('LOCAL_SUPPORTER','Local Supporter','{"umkm_supports":5}') on conflict (code) do nothing;
