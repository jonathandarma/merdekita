import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
export const isSupabaseConfigured = Boolean(url && anon);
export function serverSupabase(token?: string) {
  if (!url || !anon) throw new Error("SUPABASE_NOT_CONFIGURED");
  return createClient(url, anon, { global: { headers: token ? { Authorization: `Bearer ${token}` } : {} }, auth: { persistSession: false, autoRefreshToken: false } });
}
export function browserSupabase() {
  if (!url || !anon) throw new Error("Supabase belum dikonfigurasi.");
  return createClient(url, anon);
}
