import {Activity} from "./types";
export const activities:Activity[]=[
{id:"10000000-0000-4000-8000-000000000001",slug:"festival-kreativitas-medan",title:"Festival Kreativitas Medan",description:"Panggung kreator muda dan UMKM lokal di Lapangan Merdeka.",category:"Creative",city:"Medan",date:"2026-08-25",xp:50,participants:168,capacity:200,kind:"event"},
{id:"10000000-0000-4000-8000-000000000002",slug:"lari-merdeka-pantai",title:"Lari Merdeka Pantai",description:"Lari pagi bersama untuk kota yang lebih sehat.",category:"Sports",city:"Medan",date:"2026-08-24",xp:50,participants:82,capacity:100,kind:"event"},
{id:"20000000-0000-4000-8000-000000000001",slug:"dukung-produk-lokal",title:"Dukung Produk Lokal",description:"Kunjungi UMKM tetangga dan bagikan ceritanya.",category:"Social",city:"Medan",date:"2026-08-31",xp:100,participants:320,capacity:1000,kind:"challenge"},
{id:"20000000-0000-4000-8000-000000000002",slug:"kenali-indonesiamu",title:"Kenali Indonesiamu",description:"Pelajari satu cerita budaya lokal hari ini.",category:"Culture",city:"Yogyakarta",date:"2026-08-22",xp:100,participants:217,capacity:1000,kind:"challenge"},
{id:"vol-pantai",slug:"bersih-pantai-belawan",title:"Bersih Pantai Belawan",description:"Aksi bersih pantai bersama Komunitas Hijau Medan.",category:"Environment",city:"Medan",date:"2026-08-23",xp:150,participants:34,capacity:60,kind:"volunteer"},
{id:"umkm-kopi",slug:"kopi-seduh-medan",title:"Kopi Seduh Medan",description:"Kopi lokal dengan Merdeka Deal 17% OFF.",category:"Beverage",city:"Medan",date:"Buka 08.00-22.00",xp:100,participants:0,capacity:0,kind:"umkm"},
{id:"com-hijau",slug:"komunitas-hijau-medan",title:"Komunitas Hijau Medan",description:"Bergerak untuk ruang hidup Medan yang lebih bersih.",category:"Environment",city:"Medan",date:"Aktif mingguan",xp:75,participants:486,capacity:0,kind:"community"}
];
