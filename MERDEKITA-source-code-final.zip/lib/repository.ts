// Server-only repository boundary. Replace the demo adapter with Supabase queries in production.
import {activities} from "./demo-data";
export function list(kind?:string,q?:string){return activities.filter(a=>(!kind||a.kind===kind)&&(!q||`${a.title} ${a.city} ${a.category}`.toLowerCase().includes(q.toLowerCase())))}
export function one(id:string){return activities.find(a=>a.id===id||a.slug===id)}
export function liveStats(){const events=list("event"), challenges=list("challenge");return {activeUsers:1284,activeEvents:events.length,completedChallenges:challenges.reduce((n,x)=>n+x.participants,0),volunteers:list("volunteer").reduce((n,x)=>n+x.participants,0),umkmSupported:list("umkm").length,index:78.4}}
export function recommendations(interests:string[]=[]){return activities.filter(a=>["event","challenge","volunteer"].includes(a.kind)).map(a=>({...a,reason:interests.length?`Cocok dengan minat ${interests.join(", ")} dan aktivitas ${a.category.toLowerCase()} di ${a.city}.`:`Aktivitas berdampak tinggi yang sedang tersedia di ${a.city}.`})).slice(0,3)}
