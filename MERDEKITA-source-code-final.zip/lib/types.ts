export type Activity={id:string;slug:string;title:string;description:string;category:string;city:string;date:string;xp:number;participants:number;capacity:number;kind:"event"|"challenge"|"volunteer"|"umkm"|"community"};
export type ApiResult<T>={success:true;data:T}|{success:false;error:{code:string;message:string}};
