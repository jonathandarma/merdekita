import {NextResponse} from "next/server";
import {ZodError} from "zod";
export const ok=<T>(data:T,status=200)=>NextResponse.json({success:true,data},{status});
export const fail=(code:string,message:string,status=400)=>NextResponse.json({success:false,error:{code,message}},{status});
export function handle(error:unknown){if(error instanceof ZodError)return fail("VALIDATION_ERROR",error.issues[0]?.message??"Invalid request");console.error(error);return fail("INTERNAL_ERROR","Terjadi gangguan. Silakan coba lagi.",500)}
