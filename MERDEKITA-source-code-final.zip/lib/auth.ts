import { NextRequest } from "next/server"; import { fail } from "./api"; import { serverSupabase, isSupabaseConfigured } from "./supabase";
export async function requireUser(req: NextRequest) {
  if (!isSupabaseConfigured) return { error: fail("SERVICE_UNAVAILABLE", "Supabase belum dikonfigurasi.", 503) };
  const token = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  if (!token) return { error: fail("UNAUTHORIZED", "Silakan masuk terlebih dahulu.", 401) };
  const supabase = serverSupabase(token); const { data, error } = await supabase.auth.getUser(token);
  if (error || !data.user) return { error: fail("UNAUTHORIZED", "Sesi tidak valid.", 401) };
  return { supabase, user: data.user };
}
export async function requireAdmin(req:NextRequest){const a=await requireUser(req);if(a.error)return a;const {data,error}=await a.supabase.from("profiles").select("role").eq("id",a.user.id).single();if(error||data?.role!=="ADMIN")return {error:fail("FORBIDDEN","Khusus administrator.",403)};return a;}
