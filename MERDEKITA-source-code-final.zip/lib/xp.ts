export const LEVELS:number[]=[0,250,500,1000,2000,3500,5000];
export function levelFor(xp:number){let index=0;for(let i=0;i<LEVELS.length;i++)if(xp>=LEVELS[i]!)index=i;const current=LEVELS[index]??0;const next=LEVELS[index+1]??null;return {level:index+1,nextThreshold:next,progress:next?Math.round(((xp-current)/(next-current))*100):100,toNext:next?next-xp:0}}
export function impactScore(input:{events:number;challenges:number;volunteer:number;umkm:number;community:number}){return input.events*10+input.challenges*15+input.volunteer*25+input.umkm*10+input.community*12}
