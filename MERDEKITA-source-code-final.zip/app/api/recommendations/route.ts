import {z} from "zod";import {ok,handle} from "@/lib/api";import {recommendations} from "@/lib/repository";
const schema=z.object({interests:z.array(z.string()).max(8).default([])});
export async function POST(req:Request){try{const input=schema.parse(await req.json());return ok({provider:process.env.OPENAI_API_KEY?"configured-ai":"deterministic-fallback",items:recommendations(input.interests)})}catch(e){return handle(e)}}
