import {NextRequest} from "next/server";import {list,liveStats} from "@/lib/repository";import {ok,handle} from "@/lib/api";
export async function GET(req:NextRequest){try{const p=req.nextUrl.searchParams;return ok({items:list(p.get("kind")??undefined,p.get("q")??undefined),stats:liveStats()})}catch(e){return handle(e)}}
