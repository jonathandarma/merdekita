import {one} from "@/lib/repository";import {ok,fail,handle} from "@/lib/api";
export async function GET(_:Request,{params}:{params:Promise<{id:string}>}){try{const item=one((await params).id);return item?ok(item):fail("NOT_FOUND","Aktivitas tidak ditemukan.",404)}catch(e){return handle(e)}}
