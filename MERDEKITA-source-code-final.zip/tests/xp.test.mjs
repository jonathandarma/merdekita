import test from 'node:test'; import assert from 'node:assert/strict';
test('XP ledger remains additive',()=>{const entries=[50,100,150];assert.equal(entries.reduce((a,b)=>a+b,0),300)});
test('duplicate event registration is represented by a unique pair',()=>{const pairs=new Set(['event-1:user-1']);pairs.add('event-1:user-1');assert.equal(pairs.size,1)});
